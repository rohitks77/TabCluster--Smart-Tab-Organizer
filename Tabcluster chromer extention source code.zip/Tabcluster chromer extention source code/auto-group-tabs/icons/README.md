# Icons Required

This folder needs PNG icons for the extension:

## Required Files

1. **icon16.png** - 16x16 pixels
   - Used in: Browser toolbar (small)
   
2. **icon48.png** - 48x48 pixels  
   - Used in: Chrome extensions page (chrome://extensions)
   
3. **icon128.png** - 128x128 pixels
   - Used in: Chrome Web Store, installation dialog

## How to Create Icons

### Option 1: Simple Icon Generator (Recommended)
1. Go to https://favicon.io/favicon-generator/
2. Pick a letter (like "G" for Group) and colors
3. Download and extract
4. Rename files to icon16.png, icon48.png, icon128.png

### Option 2: Use Any Image Editor
1. Create a square image with a simple design (like tabs stacking)
2. Export at 16x16, 48x48, and 128x128 pixels
3. Save as PNG with transparency

### Option 3: SVG to PNG
1. Create an SVG icon
2. Use an online converter to export multiple sizes

## Icon Design Tips

- Use simple, recognizable shapes
- High contrast colors work best
- Test how it looks at 16x16 (very small!)
- Avoid text (unreadable at small sizes)

## Temporary Solution

The extension will work without icons but will show Chrome's default puzzle piece icon. Add proper icons before publishing to the Chrome Web Store.
