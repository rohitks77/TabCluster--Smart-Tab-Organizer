/**
 * background.js - Service Worker for Auto Group Tabs by Domain
 * 
 * This service worker handles all tab grouping operations:
 * - Fetching all tabs in the current window
 * - Extracting domains from URLs
 * - Creating and naming tab groups
 * - Collapsing groups if requested
 * - Ungrouping all tabs
 * - Auto-collapse inactive groups
 * - Context menu actions
 * - Custom domain rules
 * - Auto-group new tabs
 * - Badge counter
 * - Save/restore sessions
 */

// Available colors for tab groups (Chrome's built-in colors)
const GROUP_COLORS = [
  'blue', 'red', 'yellow', 'green', 'pink', 
  'purple', 'cyan', 'orange', 'grey'
];

// Muted color alternatives - Chrome only supports these color names,
// but we pick softer-looking ones for "muted" mode
const MUTED_COLORS = [
  'cyan', 'grey', 'blue', 'grey', 'grey',
  'grey', 'cyan', 'grey', 'grey'
];

// Track last interaction time for each group (for auto-collapse)
const groupLastActive = new Map();

// Log when service worker starts
console.log('TabCluster: Service worker started');

// ==========================================
// BADGE COUNTER
// ==========================================

/**
 * Update the badge counter with tab count
 */
async function updateBadge() {
  try {
    const prefs = await chrome.storage.local.get(['showBadge']);
    
    if (prefs.showBadge === false) {
      await chrome.action.setBadgeText({ text: '' });
      return;
    }
    
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const count = tabs.length;
    
    await chrome.action.setBadgeText({ text: count.toString() });
    await chrome.action.setBadgeBackgroundColor({ color: '#6366f1' });
  } catch (error) {
    console.error('Error updating badge:', error);
  }
}

// Update badge on startup
updateBadge();

// Update badge when tabs change
chrome.tabs.onCreated.addListener(updateBadge);
chrome.tabs.onRemoved.addListener(updateBadge);
chrome.tabs.onActivated.addListener(updateBadge);

// ==========================================
// AUTO-GROUP NEW TABS
// ==========================================

/**
 * Handle tab URL updates for auto-grouping
 * This is more reliable than onCreated because the URL is available
 */
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // Only act when page is completely loaded
  if (changeInfo.status !== 'complete') return;
  
  // Must have a valid http/https URL
  if (!tab.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
    return;
  }
  
  // Check title - skip if it looks like a new tab page
  const title = (tab.title || '').toLowerCase();
  if (title === '' || 
      title === 'new tab' || 
      title === 'new tab - google chrome' ||
      title === 'new tab - microsoft edge' ||
      title.includes('new tab') ||
      title.includes('start page') ||
      title.includes('speed dial')) {
    return;
  }
  
  try {
    // Parse URL and validate
    const urlObj = new URL(tab.url);
    const hostname = urlObj.hostname.toLowerCase();
    
    // Skip extension pages, local pages, and known new tab domains
    if (hostname === '' ||
        hostname === 'localhost' ||
        hostname === 'newtab' ||
        hostname.includes('extension') ||
        hostname.includes('newtab') ||
        hostname.includes('startpage') ||
        hostname.includes('speed-dial') ||
        hostname.endsWith('.local') ||
        hostname.endsWith('.localhost')) {
      return;
    }
    
    const prefs = await chrome.storage.local.get(['autoGroupNew', 'showNames', 'colorStyle']);
    
    if (!prefs.autoGroupNew) {
      return;
    }
    
    // Check if tab is already in a group
    if (tab.groupId !== -1 && tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
      return;
    }
    
    const domain = extractDomain(tab.url);
    
    // Skip invalid domains
    if (!domain || domain.length < 4) {
      return;
    }
    
    console.log('Auto-group: valid tab', domain, 'title:', tab.title);
    
    // Find existing group with this domain
    const groups = await chrome.tabGroups.query({ windowId: tab.windowId });
    const customRulesResult = await chrome.storage.local.get(['customRules']);
    const customRules = customRulesResult.customRules || {};
    
    // Check if domain belongs to a custom rule
    let groupName = domain;
    for (const [ruleName, ruleDomains] of Object.entries(customRules)) {
      if (ruleDomains && ruleDomains.some(d => domain.includes(d) || d.includes(domain))) {
        groupName = ruleName;
        break;
      }
    }
    
    // Find existing group with matching title
    const existingGroup = groups.find(g => g.title === groupName);
    
    if (existingGroup) {
      // Add to existing group
      console.log('Auto-group: adding to existing group', groupName);
      await chrome.tabs.group({ tabIds: [tabId], groupId: existingGroup.id });
    } else {
      // Check if there are other ungrouped tabs with same domain
      const allTabs = await chrome.tabs.query({ windowId: tab.windowId });
      const sameDomainTabs = allTabs.filter(t => {
        if (t.groupId !== -1 && t.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) return false;
        const d = extractDomain(t.url);
        if (!d) return false;
        
        // Check if same domain or same custom rule
        if (d === domain) return true;
        if (groupName !== domain && customRules[groupName]) {
          return customRules[groupName].some(rd => d.includes(rd) || rd.includes(d));
        }
        return false;
      });
      
      console.log('Auto-group: found', sameDomainTabs.length, 'tabs with same domain');
      
      if (sameDomainTabs.length >= 2) {
        // Create new group with these tabs
        const tabIds = sameDomainTabs.map(t => t.id);
        const groupId = await chrome.tabs.group({ tabIds });
        
        const colorStyle = prefs.colorStyle || 'colorful';
        const color = getColorForDomain(groupName, colorStyle);
        
        await chrome.tabGroups.update(groupId, {
          title: prefs.showNames !== false ? groupName : '',
          color: color,
          collapsed: false
        });
        
        console.log('Auto-group: created new group', groupName);
      }
    }
  } catch (error) {
    console.error('Error auto-grouping tab:', error);
  }
});

// ==========================================
// CONTEXT MENU SETUP
// ==========================================

// Create context menus when extension is installed/updated
chrome.runtime.onInstalled.addListener(() => {
  // Initialize badge
  updateBadge();
  
  // Remove any existing menus first
  chrome.contextMenus.removeAll(() => {
    // Main parent menu
    chrome.contextMenus.create({
      id: 'tabGrouper',
      title: '🗂️ TabCluster',
      contexts: ['page']
    });
    
    // Group all tabs
    chrome.contextMenus.create({
      id: 'groupAll',
      parentId: 'tabGrouper',
      title: '📦 Group All Tabs',
      contexts: ['page']
    });
    
    // Ungroup all tabs
    chrome.contextMenus.create({
      id: 'ungroupAll',
      parentId: 'tabGrouper',
      title: '📂 Ungroup All Tabs',
      contexts: ['page']
    });
    
    // Separator
    chrome.contextMenus.create({
      id: 'separator1',
      parentId: 'tabGrouper',
      type: 'separator',
      contexts: ['page']
    });
    
    // Group this domain
    chrome.contextMenus.create({
      id: 'groupThisDomain',
      parentId: 'tabGrouper',
      title: '🎯 Group This Domain Only',
      contexts: ['page']
    });
    
    // Add to custom rule
    chrome.contextMenus.create({
      id: 'addToRule',
      parentId: 'tabGrouper',
      title: '⚙️ Add Domain to Custom Rule...',
      contexts: ['page']
    });
  });
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const prefs = await chrome.storage.local.get(['collapseGroups', 'showNames', 'colorStyle']);
  
  switch (info.menuItemId) {
    case 'groupAll':
      await groupTabsByDomain(
        prefs.collapseGroups || false,
        prefs.showNames !== false,
        prefs.colorStyle || 'colorful'
      );
      break;
      
    case 'ungroupAll':
      await ungroupAllTabs();
      break;
      
    case 'groupThisDomain':
      if (tab && tab.url) {
        const domain = extractDomain(tab.url);
        if (domain) {
          await groupSingleDomain(domain, prefs);
        }
      }
      break;
      
    case 'addToRule':
      // Store the domain for the popup to handle
      if (tab && tab.url) {
        const domain = extractDomain(tab.url);
        if (domain) {
          await chrome.storage.local.set({ pendingRuleDomain: domain });
        }
      }
      break;
  }
});

// ==========================================
// KEYBOARD SHORTCUTS
// ==========================================

chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'group-tabs') {
    // Toggle group/ungroup
    const stats = await getStats();
    if (stats.success && stats.stats.groupCount > 0) {
      await ungroupAllTabs();
    } else {
      const prefs = await chrome.storage.local.get(['collapseGroups', 'showNames', 'colorStyle']);
      await groupTabsByDomain(
        prefs.collapseGroups || false,
        prefs.showNames !== false,
        prefs.colorStyle || 'colorful'
      );
    }
  }
});

// ==========================================
// AUTO-COLLAPSE TIMER
// ==========================================

// Start or restart the auto-collapse alarm
async function setupAutoCollapseAlarm() {
  const prefs = await chrome.storage.local.get(['autoCollapseEnabled', 'autoCollapseMinutes']);
  
  // Clear existing alarm
  await chrome.alarms.clear('autoCollapse');
  
  if (prefs.autoCollapseEnabled && prefs.autoCollapseMinutes > 0) {
    // Check every minute
    chrome.alarms.create('autoCollapse', { periodInMinutes: 1 });
  }
}

// Handle alarm
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'autoCollapse') {
    await autoCollapseInactiveGroups();
  }
});

// Track when a tab becomes active (user interaction)
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
      // Update last active time for this group
      groupLastActive.set(tab.groupId, Date.now());
      
      // Expand the active group
      try {
        await chrome.tabGroups.update(tab.groupId, { collapsed: false });
      } catch (e) {
        // Group may no longer exist
      }
    }
  } catch (e) {
    // Tab may no longer exist
  }
});

// Auto-collapse groups that haven't been active for X minutes
async function autoCollapseInactiveGroups() {
  const prefs = await chrome.storage.local.get(['autoCollapseEnabled', 'autoCollapseMinutes']);
  
  if (!prefs.autoCollapseEnabled || !prefs.autoCollapseMinutes) {
    return;
  }
  
  const thresholdMs = prefs.autoCollapseMinutes * 60 * 1000;
  const now = Date.now();
  
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const activeTab = tabs.find(t => t.active);
    const activeGroupId = activeTab ? activeTab.groupId : null;
    
    // Get all unique groups
    const groups = new Set();
    for (const tab of tabs) {
      if (tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
        groups.add(tab.groupId);
      }
    }
    
    // Collapse inactive groups
    for (const groupId of groups) {
      // Skip the active tab's group
      if (groupId === activeGroupId) {
        groupLastActive.set(groupId, now);
        continue;
      }
      
      const lastActive = groupLastActive.get(groupId) || 0;
      if (now - lastActive > thresholdMs) {
        try {
          await chrome.tabGroups.update(groupId, { collapsed: true });
        } catch (e) {
          // Group may no longer exist
        }
      }
    }
  } catch (error) {
    console.error('Error in auto-collapse:', error);
  }
}

// Initialize alarm on service worker start
setupAutoCollapseAlarm();

/**
 * Collapse all groups except the active tab's group
 * Called when user enables "Auto Collapse" setting
 */
async function collapseAllGroupsNow() {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const activeTab = tabs.find(t => t.active);
    const activeGroupId = activeTab ? activeTab.groupId : null;
    
    // Get all unique groups
    const groups = new Set();
    for (const tab of tabs) {
      if (tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
        groups.add(tab.groupId);
      }
    }
    
    // Collapse all groups except the active one
    for (const groupId of groups) {
      if (groupId !== activeGroupId) {
        try {
          await chrome.tabGroups.update(groupId, { collapsed: true });
        } catch (e) {
          // Group may no longer exist
        }
      }
    }
    
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Expand all groups (when user disables "Collapse others")
 */
async function expandAllGroups() {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    const groups = new Set();
    for (const tab of tabs) {
      if (tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
        groups.add(tab.groupId);
      }
    }
    
    for (const groupId of groups) {
      try {
        await chrome.tabGroups.update(groupId, { collapsed: false });
      } catch (e) {
        // Group may no longer exist
      }
    }
    
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Update all group labels (show or hide domain names)
 * 
 * @param {boolean} showLabels - Whether to show domain labels
 */
async function updateGroupLabels(showLabels) {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    // Build domain -> groupId map
    const groupDomains = new Map();
    for (const tab of tabs) {
      if (tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
        const domain = extractDomain(tab.url);
        if (domain && !groupDomains.has(tab.groupId)) {
          groupDomains.set(tab.groupId, domain);
        }
      }
    }
    
    // Update each group
    for (const [groupId, domain] of groupDomains) {
      try {
        const title = showLabels ? domain : '';
        await chrome.tabGroups.update(groupId, { title });
      } catch (e) {
        // Group may no longer exist
      }
    }
    
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Update all group colors based on style preference
 * 
 * @param {string} colorStyle - 'colorful', 'muted', or 'grey'
 */
async function updateGroupColors(colorStyle) {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    // Build domain -> groupId map
    const groupDomains = new Map();
    for (const tab of tabs) {
      if (tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
        const domain = extractDomain(tab.url);
        if (domain && !groupDomains.has(tab.groupId)) {
          groupDomains.set(tab.groupId, domain);
        }
      }
    }
    
    // Update each group's color
    for (const [groupId, domain] of groupDomains) {
      try {
        let color;
        if (colorStyle === 'grey') {
          color = 'grey';
        } else if (colorStyle === 'muted') {
          color = getColorForDomain(domain, true);
        } else {
          color = getColorForDomain(domain, false);
        }
        await chrome.tabGroups.update(groupId, { color });
      } catch (e) {
        // Group may no longer exist
      }
    }
    
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Generate a consistent hash from a string
 * Same input always produces the same output
 * 
 * @param {string} str - The string to hash
 * @returns {number} - A positive integer hash
 */
function hashString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  return Math.abs(hash);
}

/**
 * Get a consistent color for a domain based on its name
 * Same domain always gets the same color
 * 
 * @param {string} domain - The domain name
 * @param {boolean} muted - Whether to use muted colors
 * @returns {string} - A Chrome tab group color
 */
function getColorForDomain(domain, muted = false) {
  const hash = hashString(domain);
  const colors = muted ? MUTED_COLORS : GROUP_COLORS;
  return colors[hash % colors.length];
}

/**
 * Extract the base (root) domain from a hostname
 * Groups subdomains together: mail.google.com -> google.com
 * 
 * @param {string} hostname - The full hostname
 * @returns {string} - The base domain
 */
function getBaseDomain(hostname) {
  // List of known multi-part TLDs (add more as needed)
  const multiPartTLDs = [
    'co.uk', 'co.jp', 'co.kr', 'co.nz', 'co.za', 'co.in',
    'com.au', 'com.br', 'com.cn', 'com.mx', 'com.tw',
    'org.uk', 'net.au', 'gov.uk', 'ac.uk'
  ];
  
  const parts = hostname.toLowerCase().split('.');
  
  // Handle localhost or single-part domains
  if (parts.length <= 2) {
    return hostname;
  }
  
  // Check for multi-part TLDs
  const lastTwo = parts.slice(-2).join('.');
  if (multiPartTLDs.includes(lastTwo)) {
    // For multi-part TLD, take last 3 parts (e.g., bbc.co.uk)
    return parts.slice(-3).join('.');
  }
  
  // Standard case: take last 2 parts (e.g., google.com from mail.google.com)
  return parts.slice(-2).join('.');
}

/**
 * Get the effective domain for a URL, considering custom rules
 * 
 * @param {string} url - The full URL
 * @param {object} customRules - Object mapping rule names to domain arrays
 * @returns {object} - { domain, ruleName } or { domain, ruleName: null }
 */
async function getEffectiveDomain(url, customRules = null) {
  const domain = extractDomain(url);
  if (!domain) return { domain: null, ruleName: null };
  
  // Load custom rules if not provided
  if (!customRules) {
    const stored = await chrome.storage.local.get(['customRules']);
    customRules = stored.customRules || {};
  }
  
  // Check if domain matches any custom rule
  for (const [ruleName, domains] of Object.entries(customRules)) {
    if (domains && domains.includes(domain)) {
      return { domain: ruleName, ruleName: ruleName };
    }
  }
  
  return { domain, ruleName: null };
}

/**
 * Extract the domain (hostname) from a URL
 * Handles edge cases like chrome:// URLs, invalid URLs, etc.
 * 
 * @param {string} url - The full URL
 * @returns {string|null} - The domain or null if invalid
 */
function extractDomain(url) {
  // Handle empty or undefined URLs
  if (!url || typeof url !== 'string') {
    return null;
  }
  
  // Skip special Chrome URLs that can't be grouped meaningfully
  const skipProtocols = [
    'chrome://',
    'chrome-extension://',
    'edge://',
    'about:',
    'file://',
    'devtools://'
  ];
  
  for (const protocol of skipProtocols) {
    if (url.startsWith(protocol)) {
      return null;
    }
  }
  
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname;
    
    // Return the base domain (groups subdomains together)
    return hostname ? getBaseDomain(hostname) : null;
  } catch (error) {
    // Invalid URL - return null
    console.warn('Invalid URL:', url);
    return null;
  }
}

/**
 * Group all tabs in the current window by their domain
 * 
 * @param {boolean} collapse - Whether to collapse groups after creating
 * @param {boolean} showNames - Whether to show domain names on groups
 * @param {string} colorStyle - Color style: 'colorful', 'muted', or 'grey'
 * @param {boolean} useCustomRules - Whether to apply custom grouping rules
 * @returns {object} - Result with success status and message
 */
async function groupTabsByDomain(collapse, showNames = true, colorStyle = 'colorful', useCustomRules = true) {
  try {
    // Load custom rules
    const stored = await chrome.storage.local.get(['customRules']);
    const customRules = useCustomRules ? (stored.customRules || {}) : {};
    
    // Get all tabs in the current window
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    if (tabs.length === 0) {
      return { success: false, message: 'No tabs found' };
    }
    
    // Find the currently active tab to keep its group expanded
    const activeTab = tabs.find(tab => tab.active);
    let activeDomain = null;
    if (activeTab) {
      const activeResult = await getEffectiveDomain(activeTab.url, customRules);
      activeDomain = activeResult.domain;
    }
    
    // Group tabs by domain (using custom rules if available)
    const domainMap = new Map();
    
    for (const tab of tabs) {
      const { domain, ruleName } = await getEffectiveDomain(tab.url, customRules);
      
      // Skip tabs with invalid or special URLs
      if (!domain) {
        continue;
      }
      
      // Add tab to its domain group
      if (!domainMap.has(domain)) {
        domainMap.set(domain, { tabIds: [], isCustomRule: !!ruleName });
      }
      domainMap.get(domain).tabIds.push(tab.id);
    }
    
    // No valid tabs to group
    if (domainMap.size === 0) {
      return { 
        success: false, 
        message: 'No groupable tabs found (only special pages)' 
      };
    }
    
    // Create tab groups for each domain
    let groupsCreated = 0;
    
    for (const [domain, data] of domainMap) {
      const tabIds = data.tabIds;
      
      // Only create a group if there's at least 1 tab
      // (you could change this to 2 if you only want groups with multiple tabs)
      if (tabIds.length >= 1) {
        try {
          // Create the tab group
          const groupId = await chrome.tabs.group({ tabIds: tabIds });
          
          // Track this group as recently active
          groupLastActive.set(groupId, Date.now());
          
          // Check if this group contains the active tab
          const isActiveGroup = (domain === activeDomain);
          
          // If collapse is enabled, collapse all groups EXCEPT the active tab's group
          const shouldCollapse = collapse && !isActiveGroup;
          
          // Get color based on style preference
          let groupColor;
          if (colorStyle === 'grey') {
            groupColor = 'grey';
          } else if (colorStyle === 'muted') {
            groupColor = getColorForDomain(domain, true);
          } else {
            groupColor = getColorForDomain(domain, false);
          }
          
          // Build group properties
          const groupProps = {
            color: groupColor,
            collapsed: shouldCollapse
          };
          
          // Add title if showNames is enabled
          if (showNames) {
            // Add a custom icon for rule-based groups
            const prefix = data.isCustomRule ? '📁 ' : '';
            // Truncate long domain names
            const title = prefix + (domain.length > 28 
              ? domain.substring(0, 25) + '...' 
              : domain);
            groupProps.title = title;
          }
          
          // Update group properties
          await chrome.tabGroups.update(groupId, groupProps);
          
          groupsCreated++;
        } catch (groupError) {
          console.error(`Error creating group for ${domain}:`, groupError);
          // Continue with other groups even if one fails
        }
      }
    }
    
    if (groupsCreated === 0) {
      return { success: false, message: 'Could not create any groups' };
    }
    
    return { 
      success: true, 
      message: `Created ${groupsCreated} group${groupsCreated > 1 ? 's' : ''}` 
    };
    
  } catch (error) {
    console.error('Error grouping tabs:', error);
    return { success: false, message: 'Error: ' + error.message };
  }
}

/**
 * Group only tabs from a specific domain
 * 
 * @param {string} targetDomain - The domain to group
 * @param {object} prefs - User preferences
 */
async function groupSingleDomain(targetDomain, prefs = {}) {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const matchingTabIds = [];
    
    for (const tab of tabs) {
      const domain = extractDomain(tab.url);
      if (domain === targetDomain) {
        matchingTabIds.push(tab.id);
      }
    }
    
    if (matchingTabIds.length === 0) {
      return { success: false, message: 'No tabs found for this domain' };
    }
    
    const groupId = await chrome.tabs.group({ tabIds: matchingTabIds });
    
    // Get color based on style preference
    const colorStyle = prefs.colorStyle || 'colorful';
    let groupColor;
    if (colorStyle === 'grey') {
      groupColor = 'grey';
    } else if (colorStyle === 'muted') {
      groupColor = getColorForDomain(targetDomain, true);
    } else {
      groupColor = getColorForDomain(targetDomain, false);
    }
    
    const groupProps = {
      color: groupColor,
      collapsed: false
    };
    
    if (prefs.showNames !== false) {
      groupProps.title = targetDomain;
    }
    
    await chrome.tabGroups.update(groupId, groupProps);
    
    return { success: true, message: `Grouped ${matchingTabIds.length} tabs` };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Remove all tabs from their groups (ungroup all tabs)
 * 
 * @returns {object} - Result with success status and message
 */
async function ungroupAllTabs() {
  try {
    // Get all tabs in the current window
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    // Filter to only tabs that are in a group
    const groupedTabIds = tabs
      .filter(tab => tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE)
      .map(tab => tab.id);
    
    if (groupedTabIds.length === 0) {
      return { success: true, message: 'No grouped tabs to ungroup' };
    }
    
    // Ungroup all tabs
    await chrome.tabs.ungroup(groupedTabIds);
    
    return { 
      success: true, 
      message: `Ungrouped ${groupedTabIds.length} tab${groupedTabIds.length > 1 ? 's' : ''}` 
    };
    
  } catch (error) {
    console.error('Error ungrouping tabs:', error);
    return { success: false, message: 'Error: ' + error.message };
  }
}

/**
 * Message listener - handles messages from the popup
 */
/**
 * Preview tab groups without creating them
 * Returns list of domains, tab counts, and colors
 * 
 * @returns {object} - Result with groups array
 */
async function previewGroups() {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    if (tabs.length === 0) {
      return { success: false, message: 'No tabs found' };
    }
    
    // Group tabs by domain
    const domainMap = new Map();
    
    for (const tab of tabs) {
      const domain = extractDomain(tab.url);
      if (!domain) continue;
      
      if (!domainMap.has(domain)) {
        domainMap.set(domain, 0);
      }
      domainMap.set(domain, domainMap.get(domain) + 1);
    }
    
    if (domainMap.size === 0) {
      return { success: false, message: 'No groupable tabs found' };
    }
    
    // Build preview data with consistent colors
    const groups = [];
    for (const [domain, count] of domainMap) {
      groups.push({
        domain: domain,
        count: count,
        color: getColorForDomain(domain)
      });
    }
    
    // Sort by tab count (most tabs first)
    groups.sort((a, b) => b.count - a.count);
    
    return { success: true, groups: groups };
    
  } catch (error) {
    console.error('Error previewing groups:', error);
    return { success: false, message: 'Error: ' + error.message };
  }
}

/**
 * Get all tabs for quick search
 * 
 * @param {string} query - Search query
 * @returns {object} - List of matching tabs
 */
async function searchTabs(query) {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const lowerQuery = query.toLowerCase();
    
    const results = [];
    for (const tab of tabs) {
      const title = (tab.title || '').toLowerCase();
      const url = (tab.url || '').toLowerCase();
      const domain = extractDomain(tab.url) || '';
      
      if (title.includes(lowerQuery) || url.includes(lowerQuery) || domain.includes(lowerQuery)) {
        results.push({
          id: tab.id,
          title: tab.title || 'Untitled',
          url: tab.url,
          domain: domain,
          favIconUrl: tab.favIconUrl,
          groupId: tab.groupId
        });
      }
    }
    
    return { success: true, tabs: results };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Jump to a specific tab
 * 
 * @param {number} tabId - The tab ID to activate
 */
async function activateTab(tabId) {
  try {
    await chrome.tabs.update(tabId, { active: true });
    return { success: true };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Get all tabs with their details for manual grouping
 * 
 * @returns {object} - List of all tabs with metadata
 */
async function getAllTabs() {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const groups = await chrome.tabGroups.query({ windowId: chrome.windows.WINDOW_ID_CURRENT });
    
    // Create a map of group IDs to group info
    const groupMap = new Map();
    for (const group of groups) {
      groupMap.set(group.id, {
        title: group.title || '',
        color: group.color
      });
    }
    
    const tabList = [];
    for (const tab of tabs) {
      const domain = extractDomain(tab.url);
      const groupInfo = groupMap.get(tab.groupId);
      
      tabList.push({
        id: tab.id,
        title: tab.title || 'Untitled',
        url: tab.url,
        domain: domain || '',
        favIconUrl: tab.favIconUrl,
        groupId: tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE ? tab.groupId : null,
        groupTitle: groupInfo ? groupInfo.title : null,
        groupColor: groupInfo ? groupInfo.color : null
      });
    }
    
    return { success: true, tabs: tabList };
  } catch (error) {
    console.error('Error getting all tabs:', error);
    return { success: false, message: error.message };
  }
}

/**
 * Create a manual group from selected tabs
 * 
 * @param {number[]} tabIds - Array of tab IDs to group
 * @param {string} groupName - Name for the new group
 * @param {string} groupColor - Color for the new group
 * @returns {object} - Result with success status
 */
async function createManualGroup(tabIds, groupName, groupColor) {
  try {
    if (!tabIds || tabIds.length === 0) {
      return { success: false, message: 'No tabs selected' };
    }
    
    // Create the tab group
    const groupId = await chrome.tabs.group({ tabIds: tabIds });
    
    // Track this group as recently active
    groupLastActive.set(groupId, Date.now());
    
    // Update group properties
    await chrome.tabGroups.update(groupId, {
      title: groupName || '',
      color: groupColor || 'blue',
      collapsed: false
    });
    
    return { 
      success: true, 
      message: `Created group "${groupName}" with ${tabIds.length} tabs`,
      groupId: groupId
    };
  } catch (error) {
    console.error('Error creating manual group:', error);
    return { success: false, message: error.message };
  }
}

/**
 * Get current tab statistics
 * 
 * @returns {object} - Stats including tab count, domain count, and group count
 */
async function getStats() {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    
    // Count unique domains
    const domains = new Set();
    for (const tab of tabs) {
      const domain = extractDomain(tab.url);
      if (domain) {
        domains.add(domain);
      }
    }
    
    // Count unique groups
    const groups = new Set();
    for (const tab of tabs) {
      if (tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
        groups.add(tab.groupId);
      }
    }
    
    return {
      success: true,
      stats: {
        tabCount: tabs.length,
        domainCount: domains.size,
        groupCount: groups.size
      }
    };
    
  } catch (error) {
    console.error('Error getting stats:', error);
    return { success: false, message: 'Error: ' + error.message };
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle different actions
  switch (message.action) {
    case 'groupTabs':
      // Group tabs by domain
      groupTabsByDomain(message.collapse, message.showNames, message.colorStyle || 'colorful')
        .then(sendResponse);
      // Return true to indicate we'll respond asynchronously
      return true;
      
    case 'ungroupTabs':
      // Ungroup all tabs
      ungroupAllTabs()
        .then(sendResponse);
      // Return true to indicate we'll respond asynchronously
      return true;
      
    case 'previewGroups':
      // Preview groups without creating them
      previewGroups()
        .then(sendResponse);
      return true;
      
    case 'getStats':
      // Get tab statistics
      getStats()
        .then(sendResponse);
      return true;
      
    case 'searchTabs':
      // Search tabs
      searchTabs(message.query)
        .then(sendResponse);
      return true;
      
    case 'activateTab':
      // Jump to a specific tab
      activateTab(message.tabId)
        .then(sendResponse);
      return true;
      
    case 'getAllTabs':
      // Get all tabs for manual grouping
      getAllTabs()
        .then(sendResponse);
      return true;
      
    case 'createManualGroup':
      // Create a manual group from selected tabs
      createManualGroup(message.tabIds, message.groupName, message.groupColor)
        .then(sendResponse);
      return true;
      
    case 'updateAutoCollapse':
      // Update auto-collapse settings
      setupAutoCollapseAlarm()
        .then(() => sendResponse({ success: true }));
      return true;
      
    case 'collapseAllNow':
      // Collapse all groups except active one immediately
      collapseAllGroupsNow()
        .then(sendResponse);
      return true;
      
    case 'expandAllGroups':
      // Expand all groups
      expandAllGroups()
        .then(sendResponse);
      return true;
      
    case 'updateGroupLabels':
      // Update group labels (show/hide)
      updateGroupLabels(message.showLabels)
        .then(sendResponse);
      return true;
      
    case 'updateGroupColors':
      // Update group colors
      updateGroupColors(message.colorStyle)
        .then(sendResponse);
      return true;
      
    case 'getCustomRules':
      // Get custom grouping rules
      chrome.storage.local.get(['customRules'])
        .then(result => sendResponse({ success: true, rules: result.customRules || {} }));
      return true;
      
    case 'saveCustomRules':
      // Save custom grouping rules
      chrome.storage.local.set({ customRules: message.rules })
        .then(() => sendResponse({ success: true }));
      return true;
      
    case 'updateBadge':
      // Update badge counter
      updateBadge()
        .then(() => sendResponse({ success: true }));
      return true;
      
    case 'saveSession':
      // Save current session
      saveSession(message.name)
        .then(sendResponse);
      return true;
      
    case 'getSessions':
      // Get all saved sessions
      getSessions()
        .then(sendResponse);
      return true;
      
    case 'restoreSession':
      // Restore a saved session
      restoreSession(message.sessionId)
        .then(sendResponse);
      return true;
      
    case 'deleteSession':
      // Delete a saved session
      deleteSession(message.sessionId)
        .then(sendResponse);
      return true;
      
    default:
      sendResponse({ success: false, message: 'Unknown action' });
      return false;
  }
});

// ==========================================
// SESSIONS FUNCTIONALITY
// ==========================================

/**
 * Save current tab groups as a session
 * @param {string} name - Session name
 */
async function saveSession(name) {
  try {
    const tabs = await chrome.tabs.query({ currentWindow: true });
    const groups = await chrome.tabGroups.query({ windowId: chrome.windows.WINDOW_ID_CURRENT });
    
    // Filter out chrome:// and about: URLs, build session data
    const sessionTabs = [];
    for (const tab of tabs) {
      // Skip internal browser pages
      if (tab.url && !tab.url.startsWith('chrome://') && !tab.url.startsWith('about:') && !tab.url.startsWith('chrome-extension://')) {
        sessionTabs.push({
          url: tab.url,
          title: tab.title || 'Untitled',
          groupId: tab.groupId,
          pinned: tab.pinned || false
        });
      }
    }
    
    const sessionGroups = groups.map(group => ({
      id: group.id,
      title: group.title || '',
      color: group.color || 'grey',
      collapsed: group.collapsed || false
    }));
    
    const session = {
      id: Date.now().toString(),
      name: name || `Session ${new Date().toLocaleString()}`,
      createdAt: new Date().toISOString(),
      tabs: sessionTabs,
      groups: sessionGroups,
      tabCount: sessionTabs.length,
      groupCount: groups.length
    };
    
    // Get existing sessions
    const result = await chrome.storage.local.get(['savedSessions']);
    const sessions = result.savedSessions || [];
    
    // Add new session at the beginning
    sessions.unshift(session);
    
    // Keep only last 10 sessions
    if (sessions.length > 10) {
      sessions.pop();
    }
    
    await chrome.storage.local.set({ savedSessions: sessions });
    
    console.log('Session saved:', session.name, 'with', sessionTabs.length, 'tabs');
    return { success: true, session };
  } catch (error) {
    console.error('Error saving session:', error);
    return { success: false, message: error.message };
  }
}

/**
 * Get all saved sessions
 */
async function getSessions() {
  try {
    const result = await chrome.storage.local.get(['savedSessions']);
    return { success: true, sessions: result.savedSessions || [] };
  } catch (error) {
    return { success: false, message: error.message };
  }
}

/**
 * Restore a saved session
 * @param {string} sessionId - Session ID to restore
 */
async function restoreSession(sessionId) {
  try {
    console.log('Restoring session:', sessionId);
    const result = await chrome.storage.local.get(['savedSessions']);
    const sessions = result.savedSessions || [];
    const session = sessions.find(s => s.id === sessionId);
    
    if (!session) {
      console.error('Session not found:', sessionId);
      return { success: false, message: 'Session not found' };
    }
    
    console.log('Found session:', session.name, 'with', session.tabs.length, 'tabs');
    console.log('Session groups:', JSON.stringify(session.groups));
    
    // Get current window
    const currentWindow = await chrome.windows.getCurrent();
    console.log('Current window ID:', currentWindow.id);
    
    // Separate tabs by group
    const ungroupedTabs = session.tabs.filter(t => 
      t.groupId === -1 || t.groupId === chrome.tabGroups.TAB_GROUP_ID_NONE || !t.groupId
    );
    const groupedTabs = session.tabs.filter(t => 
      t.groupId && t.groupId !== -1 && t.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE
    );
    
    console.log('Ungrouped tabs:', ungroupedTabs.length, 'Grouped tabs:', groupedTabs.length);
    
    // First, create all ungrouped tabs
    for (const savedTab of ungroupedTabs) {
      if (savedTab.url && !savedTab.url.startsWith('about:blank') && !savedTab.url.startsWith('chrome://')) {
        try {
          await chrome.tabs.create({
            windowId: currentWindow.id,
            url: savedTab.url,
            pinned: savedTab.pinned || false
          });
          console.log('Created ungrouped tab:', savedTab.url);
        } catch (e) {
          console.error('Error creating tab:', savedTab.url, e);
        }
      }
    }
    
    // Group tabs by their original group ID
    const tabsByGroup = new Map();
    for (const tab of groupedTabs) {
      if (!tabsByGroup.has(tab.groupId)) {
        tabsByGroup.set(tab.groupId, []);
      }
      tabsByGroup.get(tab.groupId).push(tab);
    }
    
    console.log('Groups to create:', tabsByGroup.size);
    
    // Create tabs for each group and group them together
    for (const [oldGroupId, tabs] of tabsByGroup) {
      const savedGroup = session.groups.find(g => g.id === oldGroupId);
      const createdTabIds = [];
      
      console.log('Creating group:', savedGroup?.title || oldGroupId, 'with', tabs.length, 'tabs');
      console.log('Saved group info:', JSON.stringify(savedGroup));
      
      // Create all tabs for this group
      for (const savedTab of tabs) {
        if (savedTab.url && !savedTab.url.startsWith('about:blank') && !savedTab.url.startsWith('chrome://')) {
          try {
            const newTab = await chrome.tabs.create({
              windowId: currentWindow.id,
              url: savedTab.url,
              pinned: savedTab.pinned || false,
              active: false  // Don't activate to avoid focus issues
            });
            createdTabIds.push(newTab.id);
            console.log('Created tab:', savedTab.url, 'with ID:', newTab.id);
          } catch (e) {
            console.error('Error creating tab:', savedTab.url, e);
          }
        }
      }
      
      // Small delay to ensure tabs are ready
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Group the tabs together
      if (createdTabIds.length > 0) {
        try {
          console.log('Grouping tab IDs:', createdTabIds);
          const newGroupId = await chrome.tabs.group({ 
            tabIds: createdTabIds
          });
          console.log('Created new group with ID:', newGroupId);
          
          // Apply the group styling
          if (savedGroup) {
            await chrome.tabGroups.update(newGroupId, {
              title: savedGroup.title || '',
              color: savedGroup.color || 'grey',
              collapsed: false
            });
            console.log('Applied group style:', savedGroup.title, savedGroup.color);
          } else {
            // If no saved group info, just give it a default style
            await chrome.tabGroups.update(newGroupId, {
              title: 'Restored',
              color: 'grey',
              collapsed: false
            });
            console.log('Applied default group style');
          }
        } catch (e) {
          console.error('Error creating group:', e);
        }
      }
    }
    
    console.log('Session restored successfully');
    return { success: true };
  } catch (error) {
    console.error('Error restoring session:', error);
    return { success: false, message: error.message };
  }
}

/**
 * Delete a saved session
 * @param {string} sessionId - Session ID to delete
 */
async function deleteSession(sessionId) {
  try {
    console.log('Deleting session:', sessionId);
    const result = await chrome.storage.local.get(['savedSessions']);
    const sessions = result.savedSessions || [];
    console.log('Current sessions:', sessions.length);
    
    const filtered = sessions.filter(s => s.id !== sessionId);
    console.log('After filter:', filtered.length);
    
    await chrome.storage.local.set({ savedSessions: filtered });
    console.log('Session deleted successfully');
    return { success: true };
  } catch (error) {
    console.error('Error deleting session:', error);
    return { success: false, message: error.message };
  }
}
