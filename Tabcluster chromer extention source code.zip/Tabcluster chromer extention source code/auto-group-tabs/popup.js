/**
 * popup.js - Handles UI interactions and communicates with the service worker
 * 
 * This script runs when the popup is opened. It:
 * 1. Loads saved preferences (collapse checkbox state)
 * 2. Sends messages to background.js to perform tab operations
 * 3. Displays status messages to the user
 * 4. Handles quick search functionality
 * 5. Manages custom grouping rules
 */

// DOM Elements
const groupBtn = document.getElementById('groupBtn');
const collapseCheckbox = document.getElementById('collapseCheckbox');
const showNamesCheckbox = document.getElementById('showNamesCheckbox');
const colorStyleSelect = document.getElementById('colorStyleSelect');
const statusDiv = document.getElementById('status');
const previewBtn = document.getElementById('previewBtn');
const previewPanel = document.getElementById('previewPanel');
const previewList = document.getElementById('previewList');
const previewCountBadge = document.getElementById('previewCount');

// Search Elements
const searchInput = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');

// Auto-collapse timer elements
const autoCollapseCheckbox = document.getElementById('autoCollapseCheckbox');
const autoCollapseMinutes = document.getElementById('autoCollapseMinutes');

// New feature elements
const themeToggle = document.getElementById('themeToggle');
const autoGroupCheckbox = document.getElementById('autoGroupCheckbox');
const badgeCheckbox = document.getElementById('badgeCheckbox');

// Sessions elements
const sessionsBtn = document.getElementById('sessionsBtn');
const sessionsPanel = document.getElementById('sessionsPanel');
const sessionNameInput = document.getElementById('sessionNameInput');
const saveSessionBtn = document.getElementById('saveSessionBtn');
const sessionsList = document.getElementById('sessionsList');

// Custom Rules Elements
const customRulesBtn = document.getElementById('customRulesBtn');
const customRulesPanel = document.getElementById('customRulesPanel');
const addRuleBtn = document.getElementById('addRuleBtn');
const rulesList = document.getElementById('rulesList');
const ruleModal = document.getElementById('ruleModal');
const ruleModalTitle = document.getElementById('ruleModalTitle');
const ruleNameInput = document.getElementById('ruleNameInput');
const ruleDomainsInput = document.getElementById('ruleDomainsInput');
const saveRuleBtn = document.getElementById('saveRuleBtn');
const deleteRuleBtn = document.getElementById('deleteRuleBtn');
const closeRuleModal = document.getElementById('closeRuleModal');

// Manual Group Elements
const manualGroupBtn = document.getElementById('manualGroupBtn');
const manualGroupPanel = document.getElementById('manualGroupPanel');
const manualGroupName = document.getElementById('manualGroupName');
const manualGroupColor = document.getElementById('manualGroupColor');
const createManualGroupBtn = document.getElementById('createManualGroupBtn');
const manualTabsList = document.getElementById('manualTabsList');
const selectedCountEl = document.getElementById('selectedCount');
const selectAllTabs = document.getElementById('selectAllTabs');
const selectNoneTabs = document.getElementById('selectNoneTabs');
const selectUngroupedTabs = document.getElementById('selectUngroupedTabs');

// Track preview panel state
let isPreviewOpen = false;

// Track custom rules panel state
let isRulesOpen = false;

// Track sessions panel state
let isSessionsOpen = false;

// Track manual group panel state
let isManualOpen = false;

// Track selected tabs for manual grouping
let selectedTabIds = new Set();

// Track if tabs are currently grouped
let isGrouped = false;

// Current rule being edited (null for new rule)
let editingRuleName = null;

// Stats elements
const tabCountEl = document.getElementById('tabCount');
const domainCountEl = document.getElementById('domainCount');

// Help modal elements
const helpBtn = document.getElementById('helpBtn');
const helpModal = document.getElementById('helpModal');
const closeHelpModal = document.getElementById('closeHelpModal');

// Color map for consistent domain colors (matches Chrome's tab group colors)
const COLOR_MAP = {
  blue: '#6366f1',
  red: '#ef4444',
  yellow: '#f59e0b',
  green: '#10b981',
  pink: '#ec4899',
  purple: '#8b5cf6',
  cyan: '#06b6d4',
  orange: '#f97316',
  grey: '#6b7280'
};

// Search debounce timer
let searchDebounce = null;

/**
 * Display a toast notification
 * @param {string} message - The message to display
 * @param {string} type - Message type: 'success', 'error', or 'info'
 */
function showStatus(message, type) {
  statusDiv.textContent = message;
  statusDiv.className = 'toast ' + type + ' show';
  
  // Auto-hide after 3 seconds
  setTimeout(() => {
    statusDiv.classList.remove('show');
  }, 3000);
}

/**
 * Disable/enable buttons during operations
 * @param {boolean} disabled - Whether buttons should be disabled
 */
function setButtonsDisabled(disabled) {
  groupBtn.disabled = disabled;
  previewBtn.disabled = disabled;
}

/**
 * Load and display tab stats
 */
async function loadStats() {
  try {
    const response = await sendMessage({ action: 'getStats' });
    if (response && response.success) {
      if (tabCountEl) tabCountEl.textContent = response.stats.tabCount;
      if (domainCountEl) domainCountEl.textContent = response.stats.domainCount;
      
      // Update button state based on whether tabs are grouped
      isGrouped = response.stats.groupCount > 0;
      updateGroupButtonState();
    }
  } catch (error) {
    console.error('Error loading stats:', error);
  }
}

/**
 * Update the group button appearance based on state
 */
function updateGroupButtonState() {
  const btnLabel = groupBtn.querySelector('.btn-label');
  
  if (isGrouped) {
    groupBtn.classList.add('grouped');
    if (btnLabel) btnLabel.textContent = 'Ungroup';
  } else {
    groupBtn.classList.remove('grouped');
    if (btnLabel) btnLabel.textContent = 'Group';
  }
}

/**
 * Load saved preferences from chrome.storage.local
 */
async function loadPreferences() {
  try {
    const result = await chrome.storage.local.get([
      'collapseGroups', 
      'showNames', 
      'colorStyle',
      'autoCollapseEnabled',
      'autoCollapseMinutes',
      'darkMode',
      'autoGroupNew',
      'showBadge'
    ]);
    
    if (collapseCheckbox) collapseCheckbox.checked = result.collapseGroups || false;
    if (showNamesCheckbox) showNamesCheckbox.checked = result.showNames !== false;
    if (colorStyleSelect) colorStyleSelect.value = result.colorStyle || 'colorful';
    
    // Auto-collapse timer settings
    if (autoCollapseCheckbox) {
      autoCollapseCheckbox.checked = result.autoCollapseEnabled || false;
    }
    if (autoCollapseMinutes) {
      autoCollapseMinutes.value = result.autoCollapseMinutes || '5';
      autoCollapseMinutes.disabled = !result.autoCollapseEnabled;
    }
    
    // Theme
    if (result.darkMode) {
      document.documentElement.setAttribute('data-theme', 'dark');
    }
    
    // Auto-group new tabs
    if (autoGroupCheckbox) autoGroupCheckbox.checked = result.autoGroupNew || false;
    
    // Badge count (default true)
    if (badgeCheckbox) badgeCheckbox.checked = result.showBadge !== false;
  } catch (error) {
    console.error('Error loading preferences:', error);
  }
}

/**
 * Save preferences to chrome.storage.local
 */
async function savePreferences() {
  try {
    await chrome.storage.local.set({
      collapseGroups: collapseCheckbox.checked,
      showNames: showNamesCheckbox.checked,
      colorStyle: colorStyleSelect.value,
      autoCollapseEnabled: autoCollapseCheckbox.checked,
      autoCollapseMinutes: parseInt(autoCollapseMinutes.value),
      autoGroupNew: autoGroupCheckbox.checked,
      showBadge: badgeCheckbox.checked
    });
    
    // Notify background to update alarm and settings
    sendMessage({ action: 'updateAutoCollapse' });
    sendMessage({ action: 'updateBadge' });
  } catch (error) {
    console.error('Error saving preferences:', error);
  }
}

/**
 * Send a message to the background service worker
 * @param {object} message - The message to send
 * @returns {Promise} - Resolves with the response
 */
function sendMessage(message) {
  return chrome.runtime.sendMessage(message);
}

// Event Listeners

// Group/Ungroup Tabs Button Click - Toggle
groupBtn.addEventListener('click', async () => {
  setButtonsDisabled(true);
  
  if (isGrouped) {
    // Ungroup tabs
    showStatus('Ungrouping tabs...', 'info');
    
    try {
      const response = await sendMessage({ action: 'ungroupTabs' });
      
      if (response.success) {
        showStatus(response.message, 'success');
        isGrouped = false;
        updateGroupButtonState();
        loadStats();
        // Close preview if open
        if (isPreviewOpen) {
          isPreviewOpen = false;
          previewBtn.classList.remove('active');
          previewPanel.classList.remove('show');
        }
      } else {
        showStatus(response.message, 'error');
      }
    } catch (error) {
      showStatus('Error: ' + error.message, 'error');
    }
  } else {
    // Group tabs
    showStatus('Grouping tabs...', 'info');
    
    try {
      const response = await sendMessage({
        action: 'groupTabs',
        collapse: collapseCheckbox.checked,
        showNames: showNamesCheckbox.checked,
        colorStyle: colorStyleSelect.value
      });
      
      if (response.success) {
        showStatus(response.message, 'success');
        isGrouped = true;
        updateGroupButtonState();
        loadStats();
        // Close preview if open
        if (isPreviewOpen) {
          isPreviewOpen = false;
          previewBtn.classList.remove('active');
          previewPanel.classList.remove('show');
        }
      } else {
        showStatus(response.message, 'error');
      }
    } catch (error) {
      showStatus('Error: ' + error.message, 'error');
    }
  }
  
  setButtonsDisabled(false);
});

// Collapse Checkbox Change - Apply immediately if tabs are grouped
collapseCheckbox.addEventListener('change', async () => {
  savePreferences();
  
  if (isGrouped) {
    if (collapseCheckbox.checked) {
      await sendMessage({ action: 'collapseAllNow' });
      showStatus('Groups collapsed', 'success');
    } else {
      await sendMessage({ action: 'expandAllGroups' });
      showStatus('Groups expanded', 'success');
    }
  }
});

// Show Names Checkbox Change - Apply immediately if tabs are grouped
showNamesCheckbox.addEventListener('change', async () => {
  savePreferences();
  
  if (isGrouped) {
    await sendMessage({ action: 'updateGroupLabels', showLabels: showNamesCheckbox.checked });
    showStatus(showNamesCheckbox.checked ? 'Labels shown' : 'Labels hidden', 'success');
  }
});

// Color Style Dropdown Change - Apply immediately if tabs are grouped
colorStyleSelect.addEventListener('change', async () => {
  savePreferences();
  
  if (isGrouped) {
    await sendMessage({ action: 'updateGroupColors', colorStyle: colorStyleSelect.value });
    showStatus('Colors updated', 'success');
  }
});

// Auto-collapse checkbox change
autoCollapseCheckbox.addEventListener('change', () => {
  autoCollapseMinutes.disabled = !autoCollapseCheckbox.checked;
  savePreferences();
  
  if (autoCollapseCheckbox.checked) {
    showStatus('Auto-collapse enabled', 'success');
  }
});

// Auto-collapse minutes change
autoCollapseMinutes.addEventListener('change', savePreferences);

// ==========================================
// THEME TOGGLE
// ==========================================

themeToggle.addEventListener('click', async () => {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  
  if (isDark) {
    document.documentElement.removeAttribute('data-theme');
    await chrome.storage.local.set({ darkMode: false });
  } else {
    document.documentElement.setAttribute('data-theme', 'dark');
    await chrome.storage.local.set({ darkMode: true });
  }
});

// ==========================================
// AUTO-GROUP NEW TABS
// ==========================================

autoGroupCheckbox.addEventListener('change', async () => {
  savePreferences();
  
  if (autoGroupCheckbox.checked) {
    showStatus('Auto-group enabled', 'success');
  } else {
    showStatus('Auto-group disabled', 'info');
  }
});

// ==========================================
// BADGE COUNT TOGGLE
// ==========================================

badgeCheckbox.addEventListener('change', async () => {
  savePreferences();
  
  if (badgeCheckbox.checked) {
    showStatus('Badge enabled', 'success');
  } else {
    showStatus('Badge hidden', 'info');
  }
});

// ==========================================
// SESSIONS FUNCTIONALITY
// ==========================================

// Toggle sessions panel
sessionsBtn.addEventListener('click', () => {
  // Close other panels
  if (isPreviewOpen) {
    isPreviewOpen = false;
    previewBtn.classList.remove('active');
    previewPanel.classList.remove('show');
  }
  if (isRulesOpen) {
    isRulesOpen = false;
    customRulesBtn.classList.remove('active');
    customRulesPanel.classList.remove('show');
  }
  if (isManualOpen) {
    isManualOpen = false;
    manualGroupBtn.classList.remove('active');
    manualGroupPanel.classList.remove('show');
  }
  
  // Toggle sessions panel
  if (isSessionsOpen) {
    isSessionsOpen = false;
    sessionsBtn.classList.remove('active');
    sessionsPanel.classList.remove('show');
  } else {
    isSessionsOpen = true;
    sessionsBtn.classList.add('active');
    sessionsPanel.classList.add('show');
    loadSessions();
  }
});

// Save current session
saveSessionBtn.addEventListener('click', async () => {
  const name = sessionNameInput.value.trim() || `Session ${new Date().toLocaleString()}`;
  
  const response = await sendMessage({ action: 'saveSession', name });
  
  if (response.success) {
    showStatus(`Session "${name}" saved`, 'success');
    sessionNameInput.value = '';
    loadSessions();
  } else {
    showStatus(response.message || 'Error saving session', 'error');
  }
});

// Load sessions list
async function loadSessions() {
  try {
    const response = await sendMessage({ action: 'getSessions' });
    
    if (response && response.success && response.sessions && response.sessions.length > 0) {
      sessionsList.innerHTML = '';
      
      for (const session of response.sessions) {
        const item = document.createElement('div');
        item.className = 'session-item';
        
        const info = document.createElement('div');
        info.className = 'session-info';
        
        const name = document.createElement('div');
        name.className = 'session-name';
        name.textContent = session.name || 'Unnamed Session';
        
        const meta = document.createElement('div');
        meta.className = 'session-meta';
        meta.textContent = `${session.tabCount || 0} tabs · ${session.groupCount || 0} groups`;
        
        info.appendChild(name);
        info.appendChild(meta);
        
        const actions = document.createElement('div');
        actions.className = 'session-actions';
        
        // Restore button
        const restoreBtn = document.createElement('button');
        restoreBtn.className = 'session-btn';
        restoreBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>';
        restoreBtn.title = 'Restore session';
        
        // Store session ID as data attribute
        const sessionId = session.id;
        
        restoreBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          restoreBtn.disabled = true;
          showStatus('Restoring session...', 'info');
          
          try {
            const result = await sendMessage({ action: 'restoreSession', sessionId: sessionId });
            if (result && result.success) {
              showStatus('Session restored!', 'success');
              loadStats();
            } else {
              showStatus(result?.message || 'Error restoring session', 'error');
            }
          } catch (err) {
            showStatus('Error: ' + err.message, 'error');
          } finally {
            restoreBtn.disabled = false;
          }
        });
        
        // Delete button
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'session-btn delete';
        deleteBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>';
        deleteBtn.title = 'Delete session';
        
        deleteBtn.addEventListener('click', async (e) => {
          e.stopPropagation();
          deleteBtn.disabled = true;
          
          try {
            const result = await sendMessage({ action: 'deleteSession', sessionId: sessionId });
            if (result && result.success) {
              showStatus('Session deleted', 'success');
              loadSessions();
            } else {
              showStatus('Error deleting session', 'error');
              deleteBtn.disabled = false;
            }
          } catch (err) {
            showStatus('Error: ' + err.message, 'error');
            deleteBtn.disabled = false;
          }
        });
        
        actions.appendChild(restoreBtn);
        actions.appendChild(deleteBtn);
        
        item.appendChild(info);
        item.appendChild(actions);
        sessionsList.appendChild(item);
      }
    } else {
      sessionsList.innerHTML = '<div class="no-sessions">No saved sessions</div>';
    }
  } catch (error) {
    console.error('Error loading sessions:', error);
    sessionsList.innerHTML = '<div class="no-sessions">Error loading sessions</div>';
  }
}

// ==========================================
// QUICK SEARCH FUNCTIONALITY
// ==========================================

searchInput.addEventListener('input', (e) => {
  const query = e.target.value.trim();
  
  // Clear previous timeout
  if (searchDebounce) {
    clearTimeout(searchDebounce);
  }
  
  if (query.length === 0) {
    searchResults.classList.remove('show');
    return;
  }
  
  // Debounce search
  searchDebounce = setTimeout(async () => {
    const response = await sendMessage({ action: 'searchTabs', query });
    
    if (response.success && response.tabs.length > 0) {
      searchResults.innerHTML = '';
      
      for (const tab of response.tabs.slice(0, 8)) {
        const item = document.createElement('div');
        item.className = 'search-result-item';
        item.dataset.tabId = tab.id;
        
        const favicon = document.createElement('img');
        favicon.className = 'search-result-favicon';
        favicon.src = tab.favIconUrl || 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236b7280"><rect width="24" height="24" rx="4"/></svg>';
        favicon.onerror = () => { favicon.style.display = 'none'; };
        
        const info = document.createElement('div');
        info.className = 'search-result-info';
        
        const title = document.createElement('div');
        title.className = 'search-result-title';
        title.textContent = tab.title;
        
        const domain = document.createElement('div');
        domain.className = 'search-result-domain';
        domain.textContent = tab.domain;
        
        info.appendChild(title);
        info.appendChild(domain);
        item.appendChild(favicon);
        item.appendChild(info);
        
        item.addEventListener('click', async () => {
          await sendMessage({ action: 'activateTab', tabId: tab.id });
          window.close(); // Close popup after jumping to tab
        });
        
        searchResults.appendChild(item);
      }
      
      searchResults.classList.add('show');
    } else if (response.success && response.tabs.length === 0) {
      searchResults.innerHTML = '<div class="search-no-results">No tabs found</div>';
      searchResults.classList.add('show');
    } else {
      searchResults.classList.remove('show');
    }
  }, 150);
});

// Close search results when clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('.header')) {
    searchResults.classList.remove('show');
  }
});

// Handle keyboard navigation in search
searchInput.addEventListener('keydown', (e) => {
  const items = searchResults.querySelectorAll('.search-result-item');
  const activeItem = searchResults.querySelector('.search-result-item.active');
  
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    if (!activeItem && items.length > 0) {
      items[0].classList.add('active');
    } else if (activeItem && activeItem.nextElementSibling) {
      activeItem.classList.remove('active');
      activeItem.nextElementSibling.classList.add('active');
    }
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    if (activeItem && activeItem.previousElementSibling) {
      activeItem.classList.remove('active');
      activeItem.previousElementSibling.classList.add('active');
    }
  } else if (e.key === 'Enter') {
    e.preventDefault();
    const active = searchResults.querySelector('.search-result-item.active') || items[0];
    if (active) {
      active.click();
    }
  } else if (e.key === 'Escape') {
    searchInput.value = '';
    searchResults.classList.remove('show');
  }
});

// ==========================================
// CUSTOM RULES FUNCTIONALITY
// ==========================================

// Toggle custom rules panel
customRulesBtn.addEventListener('click', () => {
  // Close preview panel if open
  if (isPreviewOpen) {
    isPreviewOpen = false;
    previewBtn.classList.remove('active');
    previewPanel.classList.remove('show');
  }
  // Close sessions panel if open
  if (isSessionsOpen) {
    isSessionsOpen = false;
    sessionsBtn.classList.remove('active');
    sessionsPanel.classList.remove('show');
  }
  // Close manual panel if open
  if (isManualOpen) {
    isManualOpen = false;
    manualGroupBtn.classList.remove('active');
    manualGroupPanel.classList.remove('show');
  }
  
  if (isRulesOpen) {
    isRulesOpen = false;
    customRulesBtn.classList.remove('active');
    customRulesPanel.classList.remove('show');
  } else {
    isRulesOpen = true;
    customRulesBtn.classList.add('active');
    customRulesPanel.classList.add('show');
    loadCustomRules();
  }
});

// Load and display custom rules
async function loadCustomRules() {
  const response = await sendMessage({ action: 'getCustomRules' });
  const rules = response.rules || {};
  
  rulesList.innerHTML = '';
  
  const ruleNames = Object.keys(rules);
  
  if (ruleNames.length === 0) {
    rulesList.innerHTML = '<div class="no-rules">No custom rules yet</div>';
    return;
  }
  
  for (const name of ruleNames) {
    const domains = rules[name] || [];
    
    const item = document.createElement('div');
    item.className = 'rule-item';
    item.dataset.ruleName = name;
    
    const ruleName = document.createElement('span');
    ruleName.className = 'rule-name';
    ruleName.textContent = name;
    
    const ruleCount = document.createElement('span');
    ruleCount.className = 'rule-count';
    ruleCount.textContent = `${domains.length} domain${domains.length !== 1 ? 's' : ''}`;
    
    item.appendChild(ruleName);
    item.appendChild(ruleCount);
    
    item.addEventListener('click', () => {
      openRuleModal(name, domains);
    });
    
    rulesList.appendChild(item);
  }
}

// Open rule modal (for add or edit)
function openRuleModal(name = null, domains = []) {
  editingRuleName = name;
  
  if (name) {
    ruleModalTitle.textContent = 'Edit Rule';
    ruleNameInput.value = name;
    ruleDomainsInput.value = domains.join('\n');
    deleteRuleBtn.classList.add('show');
  } else {
    ruleModalTitle.textContent = 'Add Custom Rule';
    ruleNameInput.value = '';
    ruleDomainsInput.value = '';
    deleteRuleBtn.classList.remove('show');
  }
  
  ruleModal.classList.add('show');
  ruleNameInput.focus();
}

// Close rule modal
function closeRuleModalFn() {
  ruleModal.classList.remove('show');
  editingRuleName = null;
}

// Add Rule button click
addRuleBtn.addEventListener('click', () => {
  openRuleModal();
});

// Close modal button
closeRuleModal.addEventListener('click', closeRuleModalFn);

// Close modal when clicking backdrop
ruleModal.addEventListener('click', (e) => {
  if (e.target === ruleModal) {
    closeRuleModalFn();
  }
});

// Save rule
saveRuleBtn.addEventListener('click', async () => {
  const name = ruleNameInput.value.trim();
  const domainsText = ruleDomainsInput.value.trim();
  
  if (!name) {
    showStatus('Please enter a rule name', 'error');
    return;
  }
  
  const domains = domainsText
    .split('\n')
    .map(d => d.trim().toLowerCase())
    .filter(d => d.length > 0);
  
  if (domains.length === 0) {
    showStatus('Please enter at least one domain', 'error');
    return;
  }
  
  // Get existing rules
  const response = await sendMessage({ action: 'getCustomRules' });
  const rules = response.rules || {};
  
  // If editing and name changed, remove old rule
  if (editingRuleName && editingRuleName !== name) {
    delete rules[editingRuleName];
  }
  
  // Save new/updated rule
  rules[name] = domains;
  
  await sendMessage({ action: 'saveCustomRules', rules });
  
  showStatus(`Rule "${name}" saved!`, 'success');
  closeRuleModalFn();
  loadCustomRules();
});

// Delete rule
deleteRuleBtn.addEventListener('click', async () => {
  if (!editingRuleName) return;
  
  const response = await sendMessage({ action: 'getCustomRules' });
  const rules = response.rules || {};
  
  delete rules[editingRuleName];
  
  await sendMessage({ action: 'saveCustomRules', rules });
  
  showStatus(`Rule deleted`, 'success');
  closeRuleModalFn();
  loadCustomRules();
});

// ==========================================
// MANUAL GROUPING FUNCTIONALITY
// ==========================================

// Toggle manual group panel
manualGroupBtn.addEventListener('click', () => {
  // Close other panels
  if (isPreviewOpen) {
    isPreviewOpen = false;
    previewBtn.classList.remove('active');
    previewPanel.classList.remove('show');
  }
  if (isRulesOpen) {
    isRulesOpen = false;
    customRulesBtn.classList.remove('active');
    customRulesPanel.classList.remove('show');
  }
  if (isSessionsOpen) {
    isSessionsOpen = false;
    sessionsBtn.classList.remove('active');
    sessionsPanel.classList.remove('show');
  }
  
  // Toggle manual panel
  if (isManualOpen) {
    isManualOpen = false;
    manualGroupBtn.classList.remove('active');
    manualGroupPanel.classList.remove('show');
  } else {
    isManualOpen = true;
    manualGroupBtn.classList.add('active');
    manualGroupPanel.classList.add('show');
    loadTabsForManualGrouping();
  }
});

// Load tabs for manual grouping
async function loadTabsForManualGrouping() {
  try {
    const response = await sendMessage({ action: 'getAllTabs' });
    
    if (!response.success || !response.tabs) {
      manualTabsList.innerHTML = '<div class="no-tabs">Error loading tabs</div>';
      return;
    }
    
    manualTabsList.innerHTML = '';
    selectedTabIds.clear();
    updateSelectedCount();
    
    for (const tab of response.tabs) {
      const item = document.createElement('div');
      item.className = 'manual-tab-item';
      item.dataset.tabId = tab.id;
      
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.dataset.tabId = tab.id;
      
      const favicon = document.createElement('img');
      favicon.className = 'manual-tab-favicon';
      favicon.src = tab.favIconUrl || 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%236b7280"><rect width="24" height="24" rx="4"/></svg>';
      favicon.onerror = () => { favicon.style.display = 'none'; };
      
      const info = document.createElement('div');
      info.className = 'manual-tab-info';
      
      const title = document.createElement('div');
      title.className = 'manual-tab-title';
      title.textContent = tab.title || 'Untitled';
      title.title = tab.title || 'Untitled';
      
      const domain = document.createElement('div');
      domain.className = 'manual-tab-domain';
      domain.textContent = tab.domain || '';
      
      info.appendChild(title);
      info.appendChild(domain);
      
      item.appendChild(checkbox);
      item.appendChild(favicon);
      item.appendChild(info);
      
      // Show group badge if tab is in a group
      if (tab.groupTitle) {
        const badge = document.createElement('span');
        badge.className = 'manual-tab-group-badge';
        badge.textContent = tab.groupTitle;
        badge.style.backgroundColor = COLOR_MAP[tab.groupColor] || '#6b7280';
        badge.style.color = 'white';
        item.appendChild(badge);
      }
      
      // Click on item toggles checkbox
      item.addEventListener('click', (e) => {
        if (e.target !== checkbox) {
          checkbox.checked = !checkbox.checked;
        }
        
        if (checkbox.checked) {
          selectedTabIds.add(tab.id);
          item.classList.add('selected');
        } else {
          selectedTabIds.delete(tab.id);
          item.classList.remove('selected');
        }
        updateSelectedCount();
      });
      
      checkbox.addEventListener('change', () => {
        if (checkbox.checked) {
          selectedTabIds.add(tab.id);
          item.classList.add('selected');
        } else {
          selectedTabIds.delete(tab.id);
          item.classList.remove('selected');
        }
        updateSelectedCount();
      });
      
      manualTabsList.appendChild(item);
    }
    
    if (response.tabs.length === 0) {
      manualTabsList.innerHTML = '<div class="no-tabs">No tabs found</div>';
    }
  } catch (error) {
    console.error('Error loading tabs:', error);
    manualTabsList.innerHTML = '<div class="no-tabs">Error loading tabs</div>';
  }
}

// Update selected count badge
function updateSelectedCount() {
  const count = selectedTabIds.size;
  selectedCountEl.textContent = `${count} selected`;
  createManualGroupBtn.disabled = count === 0;
}

// Select All button
selectAllTabs.addEventListener('click', () => {
  const items = manualTabsList.querySelectorAll('.manual-tab-item');
  items.forEach(item => {
    const checkbox = item.querySelector('input[type="checkbox"]');
    const tabId = parseInt(item.dataset.tabId);
    checkbox.checked = true;
    item.classList.add('selected');
    selectedTabIds.add(tabId);
  });
  updateSelectedCount();
});

// Select None button
selectNoneTabs.addEventListener('click', () => {
  const items = manualTabsList.querySelectorAll('.manual-tab-item');
  items.forEach(item => {
    const checkbox = item.querySelector('input[type="checkbox"]');
    checkbox.checked = false;
    item.classList.remove('selected');
  });
  selectedTabIds.clear();
  updateSelectedCount();
});

// Select Ungrouped Only button
selectUngroupedTabs.addEventListener('click', async () => {
  const response = await sendMessage({ action: 'getAllTabs' });
  
  if (!response.success) return;
  
  // Clear current selection
  selectedTabIds.clear();
  
  const items = manualTabsList.querySelectorAll('.manual-tab-item');
  items.forEach(item => {
    const tabId = parseInt(item.dataset.tabId);
    const tab = response.tabs.find(t => t.id === tabId);
    const checkbox = item.querySelector('input[type="checkbox"]');
    
    if (tab && !tab.groupId) {
      checkbox.checked = true;
      item.classList.add('selected');
      selectedTabIds.add(tabId);
    } else {
      checkbox.checked = false;
      item.classList.remove('selected');
    }
  });
  
  updateSelectedCount();
});

// Create Manual Group button
createManualGroupBtn.addEventListener('click', async () => {
  if (selectedTabIds.size === 0) {
    showStatus('Please select at least one tab', 'error');
    return;
  }
  
  const groupName = manualGroupName.value.trim() || `Group ${Date.now()}`;
  const groupColor = manualGroupColor.value;
  
  createManualGroupBtn.disabled = true;
  showStatus('Creating group...', 'info');
  
  try {
    const response = await sendMessage({
      action: 'createManualGroup',
      tabIds: Array.from(selectedTabIds),
      groupName: groupName,
      groupColor: groupColor
    });
    
    if (response.success) {
      showStatus(`Created group "${groupName}" with ${selectedTabIds.size} tabs`, 'success');
      manualGroupName.value = '';
      selectedTabIds.clear();
      loadTabsForManualGrouping();
      loadStats();
      isGrouped = true;
      updateGroupButtonState();
    } else {
      showStatus(response.message || 'Error creating group', 'error');
    }
  } catch (error) {
    showStatus('Error: ' + error.message, 'error');
  } finally {
    createManualGroupBtn.disabled = false;
  }
});

// Preview Button Click - Toggle preview panel
previewBtn.addEventListener('click', async () => {
  // Close rules panel if open
  if (isRulesOpen) {
    isRulesOpen = false;
    customRulesBtn.classList.remove('active');
    customRulesPanel.classList.remove('show');
  }
  // Close sessions panel if open
  if (isSessionsOpen) {
    isSessionsOpen = false;
    sessionsBtn.classList.remove('active');
    sessionsPanel.classList.remove('show');
  }
  // Close manual panel if open
  if (isManualOpen) {
    isManualOpen = false;
    manualGroupBtn.classList.remove('active');
    manualGroupPanel.classList.remove('show');
  }
  
  // If preview is open, close it
  if (isPreviewOpen) {
    isPreviewOpen = false;
    previewBtn.classList.remove('active');
    previewPanel.classList.remove('show');
    return;
  }
  
  // Otherwise, open and load preview
  previewBtn.disabled = true;
  
  try {
    const response = await sendMessage({ action: 'previewGroups' });
    
    if (response.success) {
      // Clear previous preview
      previewList.innerHTML = '';
      
      // Update count badge
      previewCountBadge.textContent = response.groups.length;
      
      // Build preview items
      for (const group of response.groups) {
        const item = document.createElement('div');
        item.className = 'preview-item';
        
        const colorDot = document.createElement('div');
        colorDot.className = 'preview-color';
        colorDot.style.backgroundColor = COLOR_MAP[group.color] || '#6b7280';
        
        const domain = document.createElement('span');
        domain.className = 'preview-domain';
        domain.textContent = group.domain;
        domain.title = group.domain; // Tooltip for long domains
        
        const count = document.createElement('span');
        count.className = 'preview-count';
        count.textContent = `${group.count}`;
        
        item.appendChild(colorDot);
        item.appendChild(domain);
        item.appendChild(count);
        previewList.appendChild(item);
      }
      
      // Show panel and mark as open
      isPreviewOpen = true;
      previewBtn.classList.add('active');
      previewPanel.classList.add('show');
    } else {
      showStatus(response.message, 'error');
    }
  } catch (error) {
    showStatus('Error: ' + error.message, 'error');
  } finally {
    previewBtn.disabled = false;
  }
});

// Initialize - Load saved preferences and stats when popup opens
document.addEventListener('DOMContentLoaded', () => {
  loadPreferences();
  loadStats();
  
  // Detect OS and update keyboard shortcut hints
  const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
  const modKey = isMac ? '⌘' : 'Ctrl';
  
  const modKeyEl = document.getElementById('modKey');
  const modKey2El = document.getElementById('modKey2');
  if (modKeyEl) modKeyEl.textContent = modKey;
  if (modKey2El) modKey2El.textContent = modKey;
});

// ==========================================
// HELP MODAL FUNCTIONALITY
// ==========================================

// Open help modal
helpBtn.addEventListener('click', () => {
  helpModal.classList.add('show');
});

// Close help modal
closeHelpModal.addEventListener('click', () => {
  helpModal.classList.remove('show');
});

// Close help modal when clicking backdrop
helpModal.addEventListener('click', (e) => {
  if (e.target === helpModal) {
    helpModal.classList.remove('show');
  }
});
